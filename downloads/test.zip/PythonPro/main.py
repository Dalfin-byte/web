import requests
import zipfile
import os
import platform
import shutil

def fetch_versions(index_url):
    try:
        response = requests.get(index_url)
        response.raise_for_status()
    except requests.RequestException as e:
        print(f"❌ Failed to fetch version list: {e}")
        return {}

    versions = {}
    for line in response.text.strip().split("\n"):
        if "=" in line:
            version, url = line.strip().split("=", 1)
            versions[version.strip()] = url.strip()
    return versions

def list_versions(versions):
    print("\n📦 Available Versions:")
    for version in sorted(versions.keys()):
        print(f"  - Version {version}")
    print()

def prompt_user_for_version(versions):
    chosen = input("➡️  Enter the version number you want to download: ").strip()
    if chosen not in versions:
        print("⚠️ Invalid version selected.")
        return None
    return versions[chosen]

def get_minecraft_resourcepack_folder():
    system = platform.system()
    home = os.path.expanduser("~")

    if system == "Windows":
        appdata = os.getenv('APPDATA')
        if appdata:
            path = os.path.join(appdata, ".minecraft", "resourcepacks")
        else:
            path = os.path.join(home, "AppData", "Roaming", ".minecraft", "resourcepacks")
    elif system == "Darwin":  # macOS
        path = os.path.join(home, "Library", "Application Support", "minecraft", "resourcepacks")
    else:
        print(f"⚠️ Unsupported OS: {system}. Please enter folder manually.")
        return None

    if not os.path.exists(path):
        try:
            os.makedirs(path)
            print(f"📂 Created Minecraft resourcepacks folder at: {path}")
        except Exception as e:
            print(f"❌ Could not create resourcepacks folder: {e}")
            return None
    return path

def prompt_target_folder():
    print("\n📁 The program detected your Minecraft resourcepacks folder:")
    folder = get_minecraft_resourcepack_folder()
    if folder:
        print(f"➡️  {folder}")
        confirm = input("Do you want to use this folder? (Y/n): ").strip().lower()
        if confirm in ('', 'y', 'yes'):
            return folder

    folder = input("📁 Enter the path to save the folder manually: ").strip()
    if not os.path.exists(folder):
        try:
            os.makedirs(folder)
            print(f"📂 Created directory: {folder}")
        except Exception as e:
            print(f"❌ Could not create folder: {e}")
            return None
    return folder

def prompt_replace_totem(extract_to, original_totem_relpath, new_totem_filename):
    choice = input("Do you want to replace the totem texture with your own? (y/N) (Your minecraft skin texture): ").strip().lower()
    if choice not in ('y', 'yes'):
        return

    user_texture_path = input("Enter the full path to your custom totem texture image file: ").strip()
    if not os.path.isfile(user_texture_path):
        print("❌ The file you specified does not exist.")
        return

    original_totem_path = os.path.join(extract_to, original_totem_relpath)
    if not os.path.isfile(original_totem_path):
        print(f"❌ Original totem texture not found at expected path: {original_totem_path}")
        return

    backup_path = original_totem_path + ".backup"
    if not os.path.exists(backup_path):
        shutil.copy2(original_totem_path, backup_path)
        print(f"💾 Backed up original totem texture to: {backup_path}")

    new_totem_path = os.path.join(os.path.dirname(original_totem_path), new_totem_filename)
    try:
        shutil.copy2(user_texture_path, new_totem_path)
        if new_totem_path != original_totem_path:
            os.remove(original_totem_path)
        print(f"✅ Totem texture replaced successfully as: {new_totem_path}")
    except Exception as e:
        print(f"❌ Failed to replace totem texture: {e}")

def download_and_extract_zip(url, extract_to):
    filename = url.split("/")[-1]
    zip_path = os.path.join(extract_to, filename)

    print(f"\n⬇️ Downloading {filename}...")
    try:
        response = requests.get(url)
        response.raise_for_status()
        with open(zip_path, "wb") as f:
            f.write(response.content)
    except requests.RequestException as e:
        print(f"❌ Failed to download file: {e}")
        return

    print("🧩 Extracting contents...")
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
        os.remove(zip_path)
        print("✅ Download and extraction complete!\n")

        # Prompt to replace totem texture
        original_totem_relpath = "2.txt"  # Change if needed
        new_totem_filename = "finished.txt"  # Filename for replaced texture

        prompt_replace_totem(extract_to, original_totem_relpath, new_totem_filename)

    except zipfile.BadZipFile:
        print("❌ The downloaded file is not a valid ZIP archive.")

def run_wizard():
    index_url = "http://127.0.0.1:5500/Web/downloads/versions.txt"  # Replace with your real file URL

    print("WELCOME to the pack wizard.\n")

    versions = fetch_versions(index_url)
    if not versions:
        return

    list_versions(versions)

    download_url = prompt_user_for_version(versions)
    if not download_url:
        return

    target_folder = prompt_target_folder()
    if not target_folder:
        return

    download_and_extract_zip(download_url, target_folder)

if __name__ == "__main__":
    run_wizard()
